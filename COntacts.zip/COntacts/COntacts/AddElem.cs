﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COntacts
{
	public partial class AddElem : Form
	{
		public AddElem()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			//решил совместить с винформс, создания нового и редактирования
			// поиск на впфе
			if (Tag != null)
			{

				User g = Tag as User;
				g.Lastname = txbLastName.Text;
				g.Firstname = txbFirstname.Text;
				g.Phone = txbPhone.Text;
				g.Email = txbEmail.Text;
				return;
			}
			User user = new User(txbLastName.Text, txbFirstname.Text, txbPhone.Text, txbEmail.Text);
			this.Tag = user;
		}

		private void AddElem_Load(object sender, EventArgs e)
		{
			if (Tag != null)
			{
				User g = Tag as User;
				txbLastName.Text = g.Lastname;
				txbFirstname.Text = g.Firstname;
				txbPhone.Text = g.Phone;
				txbEmail.Text = g.Email;
			}

		}

		private void AddElem_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Escape)
			{
				DialogResult = DialogResult.Cancel;
			}
		}
	}
}
