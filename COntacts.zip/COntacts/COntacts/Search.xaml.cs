﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace COntacts
{
	/// <summary>
	/// Логика взаимодействия для Search.xaml
	/// </summary>
	public partial class Search : Window
	{
		public string GetSearchRequest { get => txbSearch.Text;  }
		public Search()
		{
			InitializeComponent();
		}

		private void FInd_Click(object sender, RoutedEventArgs e)
		{
			if (Tag == null) Tag = -1;
			DialogResult = true;
		}

		private void RadioButton_Checked(object sender, RoutedEventArgs e)
		{
			Tag = 1;
		}

		private void last_Checked(object sender, RoutedEventArgs e)
		{
			Tag = 2;
		}

		private void phone_Checked(object sender, RoutedEventArgs e)
		{
			Tag = 3;
		}

		private void email_Checked(object sender, RoutedEventArgs e)
		{
			Tag = 4;
		}

		private void Window_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Escape)
			{
				DialogResult = false;
			}
		}
	}
}
