﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COntacts
{
	[Serializable]
	class User
	{
		
		string lastname;
		string firstname;
		string phone;
		string email;


		public User(string lastname, string firstname, string phone, string email)
		{
			this.lastname = lastname;
			this.firstname = firstname;
			this.phone = phone;
			this.email = email;

		}

		public string Lastname { get => lastname; set => lastname = value; }
		public string Firstname { get => firstname; set => firstname = value; }
		public string Phone { get => phone; set => phone = value; }
		public string Email { get => email; set => email = value; }
	

		public  bool Equals(User obj)
		{
			return 
				   lastname == obj.lastname &&
				   firstname == obj.firstname &&
				   phone == obj.phone &&
				   email == obj.email;
		}
	}
}
