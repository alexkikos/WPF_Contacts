﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace COntacts
{
	/// <summary>
	/// Логика взаимодействия для MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		List<User> all_users;
		public MainWindow()
		{
			InitializeComponent();
			all_users = new List<User>();
		}

		private void AddNew_Click(object sender, RoutedEventArgs e)
		{
			AddElem addElem = new AddElem();
			if (addElem.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				User s = addElem.Tag as User;
				User b = new User(s.Lastname, s.Firstname, s.Phone, s.Email);
				all_users.Add(b);
				DataGrid.ItemsSource = null;
				DataGrid.ItemsSource = all_users;
			}
		}

		private void Edit_Click(object sender, RoutedEventArgs e)
		{
			if (DataGrid.SelectedItem != null)
			{
				User p = DataGrid.SelectedItem as User;
				AddElem addElem = new AddElem();
				addElem.Tag = p;
				if (addElem.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					DataGrid.ItemsSource = null;
					DataGrid.ItemsSource = all_users;
				}
			}
		}

		private void Del_Click(object sender, RoutedEventArgs e)
		{
			if (DataGrid.SelectedItems != null)
			{
				foreach (var item in DataGrid.SelectedItems)
				{
					all_users.Remove(item as User);
				}
				DataGrid.ItemsSource = null;
				DataGrid.ItemsSource = all_users;
			}
		}

		private void Find_Click(object sender, RoutedEventArgs e)
		{
			if (all_users.Count > 0)
			{
				IEnumerable<User> temp = null;
				Search search = new Search();
				if (search.ShowDialog() == true)
				{
					int index = -1;
					int.TryParse(search.Tag.ToString(), out index);
					string s = search.GetSearchRequest;
					switch (index)
					{
						case 1:
							temp = from t in all_users
								   where t.Firstname.ToLower() == s.ToLower()
								   select t;
							break;
						case 2:

							temp = from t in all_users
								   where t.Lastname.ToLower() == s.ToLower()
								   select t;
							break;
						case 3:
							temp = from t in all_users
								   where t.Phone.ToLower() == s.ToLower()
								   select t;
							break;
						case 4:
							temp = from t in all_users
								   where t.Email.ToLower() == s.ToLower()
								   select t;
							break;
					}
					if (temp != null && temp.Count() > 0)
					{
						DataGrid.ItemsSource = null;
						DataGrid.ItemsSource = temp;
					}
					else System.Windows.Forms.MessageBox.Show("Результатов нет!");
				}

			}
		}

		private void Refresh_Click(object sender, RoutedEventArgs e)
		{
			DataGrid.ItemsSource = null;
			DataGrid.ItemsSource = all_users;
		}

		private void DataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			Edit_Click(null, null);
		}

		private void btnExit_Click(object sender, RoutedEventArgs e)
		{
			this.Close();
		}

		private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if (System.Windows.Forms.MessageBox.Show("Вы действительно хотите выйти?", "", MessageBoxButtons.YesNo) != System.Windows.Forms.DialogResult.Yes)
			{
				e.Cancel = true;
			}
		}

		private void btnSave_Click(object sender, RoutedEventArgs e)
		{
			if (all_users.Count > 0)
			{
				SaveFileDialog saveFileDialog = new SaveFileDialog();
				if (saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					FileStream str = new FileStream(saveFileDialog.FileName, FileMode.Create, FileAccess.Write);
					BinaryFormatter binaryFormatter = new BinaryFormatter();
					binaryFormatter.Serialize(str, all_users);
					str.Close();
					System.Windows.Forms.MessageBox.Show("Done");
				}
			}
		}

		private void btnLoad_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				OpenFileDialog openFileDialog = new OpenFileDialog();
				if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					if (System.Windows.Forms.MessageBox.Show("Clear current list?", "Load", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == System.Windows.Forms.DialogResult.Yes)
					{
						all_users.Clear();
					}
					FileStream str = new FileStream(openFileDialog.FileName, FileMode.Open, FileAccess.Read);
					BinaryFormatter binaryFormatter = new BinaryFormatter();
					List<User> u = new List<User>();
					 u = (List<User>)binaryFormatter.Deserialize(str);
					str.Close();
					all_users.AddRange(u);
					DataGrid.ItemsSource = null;
					DataGrid.ItemsSource = all_users;
					System.Windows.Forms.MessageBox.Show("Done");
				}
			}
			catch(Exception ex)
			{
				System.Windows.Forms.MessageBox.Show(ex.Message+ex.StackTrace);
			}
		}



		private void addcntx_Click(object sender, RoutedEventArgs e)
		{
			AddNew_Click(null, null);
		}

		private void delcntx_Click(object sender, RoutedEventArgs e)
		{
			Del_Click(null, null);
		}

		private void editcntx_Click(object sender, RoutedEventArgs e)
		{
			Edit_Click(null, null);
		}
	}
}
